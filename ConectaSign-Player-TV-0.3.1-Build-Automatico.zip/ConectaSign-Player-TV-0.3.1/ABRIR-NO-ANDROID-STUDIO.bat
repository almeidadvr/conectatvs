@echo off
setlocal
cd /d "%~dp0"
if not exist "gradle\wrapper\gradle-wrapper.jar" call "%~dp0PREPARAR-PROJETO.bat"
set "STUDIO=%ProgramFiles%\Android\Android Studio\bin\studio64.exe"
if exist "%STUDIO%" (
  start "" "%STUDIO%" "%CD%"
  exit /b 0
)
set "STUDIO=%LOCALAPPDATA%\Programs\Android Studio\bin\studio64.exe"
if exist "%STUDIO%" (
  start "" "%STUDIO%" "%CD%"
  exit /b 0
)
echo Android Studio nao foi encontrado automaticamente.
echo Abra o Android Studio e escolha Open, depois selecione esta pasta:
echo %CD%
pause
