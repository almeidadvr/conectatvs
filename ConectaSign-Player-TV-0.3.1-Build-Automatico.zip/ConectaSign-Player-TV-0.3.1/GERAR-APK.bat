@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Conecta Sign - Gerar APK

echo ============================================================
echo        CONECTA SIGN PLAYER TV 0.3.1 - GERAR APK
echo ============================================================
echo.

rem 1) Locate Java 17. Android Studio includes a compatible JBR.
if not defined JAVA_HOME (
  for %%J in (
    "%ProgramFiles%\Android\Android Studio\jbr"
    "%ProgramFiles%\Android\Android Studio\jre"
    "%LOCALAPPDATA%\Programs\Android Studio\jbr"
  ) do (
    if exist "%%~J\bin\java.exe" set "JAVA_HOME=%%~J"
  )
)

if not defined JAVA_HOME (
  where java >nul 2>&1
  if errorlevel 1 (
    echo [ERRO] Java nao encontrado.
    echo Instale o Android Studio e abra este arquivo novamente.
    echo.
    pause
    exit /b 1
  )
) else (
  set "PATH=%JAVA_HOME%\bin;%PATH%"
)

echo [OK] Java localizado.

rem 2) Locate Android SDK and create local.properties automatically.
if not defined ANDROID_SDK_ROOT (
  if exist "%LOCALAPPDATA%\Android\Sdk" set "ANDROID_SDK_ROOT=%LOCALAPPDATA%\Android\Sdk"
)
if not defined ANDROID_HOME if defined ANDROID_SDK_ROOT set "ANDROID_HOME=%ANDROID_SDK_ROOT%"

if not defined ANDROID_SDK_ROOT (
  echo [ERRO] Android SDK nao encontrado em %%LOCALAPPDATA%%\Android\Sdk.
  echo Abra o Android Studio uma vez e instale o Android SDK 35 pelo SDK Manager.
  echo.
  pause
  exit /b 1
)

set "SDK_ESC=%ANDROID_SDK_ROOT:\=\\%"
> local.properties echo sdk.dir=%SDK_ESC%
echo [OK] Android SDK: %ANDROID_SDK_ROOT%

rem 3) Bootstrap Gradle Wrapper JAR if this package was downloaded without it.
if not exist "gradle\wrapper\gradle-wrapper.jar" (
  echo [INFO] Preparando Gradle Wrapper...
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -UseBasicParsing 'https://raw.githubusercontent.com/gradle/gradle/v8.9.0/gradle/wrapper/gradle-wrapper.jar' -OutFile 'gradle\wrapper\gradle-wrapper.jar' } catch { Write-Host $_.Exception.Message; exit 1 }"
  if errorlevel 1 (
    echo [ERRO] Nao foi possivel baixar o Gradle Wrapper.
    echo Verifique a conexao com a internet e tente novamente.
    echo.
    pause
    exit /b 1
  )
)

echo [OK] Gradle Wrapper pronto.
echo.
echo Compilando APK de teste. Na primeira vez o Gradle pode baixar dependencias.
echo.
call gradlew.bat --no-daemon assembleDebug
if errorlevel 1 (
  echo.
  echo ============================================================
  echo [ERRO] A compilacao falhou.
  echo Copie as ultimas linhas desta janela e envie para o ChatGPT.
  echo ============================================================
  echo.
  pause
  exit /b 1
)

set "APK=app\build\outputs\apk\debug\app-debug.apk"
if not exist "%APK%" (
  echo [ERRO] A compilacao terminou, mas o APK nao foi encontrado.
  pause
  exit /b 1
)

copy /Y "%APK%" "ConectaSign-Player-TV-0.3.1-debug.apk" >nul

echo.
echo ============================================================
echo [SUCESSO] APK GERADO!
echo.
echo Arquivo:
echo %CD%\ConectaSign-Player-TV-0.3.1-debug.apk
echo ============================================================
echo.
explorer /select,"%CD%\ConectaSign-Player-TV-0.3.1-debug.apk"
pause
