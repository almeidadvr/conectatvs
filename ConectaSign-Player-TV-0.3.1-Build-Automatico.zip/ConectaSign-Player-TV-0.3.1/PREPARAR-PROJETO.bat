@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Conecta Sign - Preparar Projeto Android

echo Preparando o projeto...

if not exist "gradle\wrapper\gradle-wrapper.jar" (
  echo Baixando Gradle Wrapper 8.9...
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -UseBasicParsing 'https://raw.githubusercontent.com/gradle/gradle/v8.9.0/gradle/wrapper/gradle-wrapper.jar' -OutFile 'gradle\wrapper\gradle-wrapper.jar' } catch { Write-Host $_.Exception.Message; exit 1 }"
  if errorlevel 1 (
    echo.
    echo ERRO: nao foi possivel baixar o Gradle Wrapper.
    echo Confira a internet e tente novamente.
    pause
    exit /b 1
  )
)

if exist "%LOCALAPPDATA%\Android\Sdk" (
  set "SDK=%LOCALAPPDATA%\Android\Sdk"
  setlocal EnableDelayedExpansion
  set "SDK_ESC=!SDK:\=\\!"
  > local.properties echo sdk.dir=!SDK_ESC!
  endlocal
)

echo Projeto preparado.
echo.
echo Agora voce pode abrir a pasta no Android Studio ou executar GERAR-APK.bat.
pause
