# Conecta Sign Player TV 0.3.1

Player de digital signage para Android TV / Google TV, integrado ao Conecta Sign Desktop.

## O que esta versão inclui

- Projeto Android pronto para abrir no Android Studio.
- Android Gradle Plugin 8.7.3 + Gradle 8.9.
- Java/JVM 17.
- compileSdk/targetSdk 35 e minSdk 26.
- Launcher para Android TV / Google TV.
- Ícone e banner próprios do Conecta Sign.
- Suporte ao controle remoto.
- Código de pareamento de 6 dígitos.
- Descoberta do servidor nas portas 8787 a 8797.
- Vídeos com Media3/ExoPlayer.
- Imagens com duração configurada pela playlist.
- Cache local para continuar reproduzindo offline.
- Heartbeat e atualização periódica da playlist.
- Tentativa de abertura após BOOT_COMPLETED.

## Antes de gerar o APK

Instale o Android Studio para Windows 11 e, no SDK Manager, tenha instalado o Android SDK Platform 35.
O Android Studio já traz um JDK compatível; o projeto usa Java 17.

## Forma mais simples: GERAR-APK.bat

1. Extraia todo o ZIP para uma pasta normal, por exemplo `C:\ConectaSignPlayer`.
2. Instale e abra o Android Studio pelo menos uma vez, para concluir a instalação do SDK.
3. Feche o Android Studio.
4. Execute `GERAR-APK.bat`.
5. Na primeira execução, o script baixa o Gradle Wrapper e as dependências do projeto.
6. Se a compilação terminar corretamente, o APK será copiado para a raiz do projeto com o nome:

   `ConectaSign-Player-TV-0.3.1-debug.apk`

O APK original também fica em:

`app\build\outputs\apk\debug\app-debug.apk`

## Pelo Android Studio

1. Execute `PREPARAR-PROJETO.bat` uma vez.
2. Execute `ABRIR-NO-ANDROID-STUDIO.bat` ou use `File > Open` no Android Studio.
3. Aguarde o Gradle Sync.
4. Use `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

## Instalação na TV

O APK debug é suficiente para testes internos. Copie para um pendrive ou envie pela rede, permita instalação de aplicativos desconhecidos na TV e instale o APK.

Na primeira abertura:

1. Informe o IP do computador que executa o Conecta Sign Desktop, por exemplo `192.168.1.50`.
2. O player procura o servidor nas portas 8787 a 8797.
3. Anote o código de 6 dígitos exibido.
4. No painel do Conecta Sign no Windows, adicione uma TV usando esse código.
5. Associe uma playlist à TV.
6. O player baixa os arquivos e começa a reprodução automaticamente.

## Rede / Firewall

A TV e o computador devem conseguir se comunicar pela rede local. No Windows, permita o Conecta Sign no Firewall para redes privadas.

## APK release

Para produção, o ideal é gerar posteriormente um APK `release` assinado com uma chave própria. Não publique nem distribua a chave de assinatura. A versão debug desta pasta é destinada a testes.

## Diagnóstico de compilação

Se `GERAR-APK.bat` falhar, não feche a janela. Copie as últimas linhas do erro ou tire uma foto e envie no chat para ajuste.
